﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using ProjectLens.Models;

namespace ProjectLens.Controllers
{
    public class TeamAwardsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        private bool IsManager()
        {
            var userId = User.Identity.GetUserId();
            var user = db.Users.Find(userId);
            return user != null && user.IsManager;
        }

        // GET: TeamAwards
        [Authorize]
        public ActionResult Index()
        {
            ViewBag.IsManager = IsManager();
            return View(db.TeamAwards.ToList());
        }

        // GET: TeamAwards/Details/5
        [Authorize]
        public ActionResult Details(int? id)
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TeamAward teamAward = db.TeamAwards.Find(id);
            if (teamAward == null)
            {
                return HttpNotFound();
            }
            return View(teamAward);
        }

        // GET: TeamAwards/Create
        [Authorize]
        public ActionResult Create()
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            return View();
        }

        // POST: TeamAwards/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,TeamName,AwardName,AwardedDate")] TeamAward teamAward)
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            if (ModelState.IsValid)
            {
                db.TeamAwards.Add(teamAward);
                db.SaveChanges();
                return RedirectToAction("Index", "Rewards"); ;
            }

            return View(teamAward);
        }

        // GET: TeamAwards/Edit/5
        [Authorize]
        public ActionResult Edit(int? id)
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TeamAward teamAward = db.TeamAwards.Find(id);
            if (teamAward == null)
            {
                return HttpNotFound();
            }
            return View(teamAward);
        }

        // POST: TeamAwards/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,TeamName,AwardName,AwardedDate")] TeamAward teamAward)
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            if (ModelState.IsValid)
            {
                db.Entry(teamAward).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", "Rewards");
            }
            return View(teamAward);
        }
        [Authorize]
        [HttpPost]
        public ActionResult Delete(int id)
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            TeamAward teamAward = db.TeamAwards.Find(id);
            if (teamAward != null)
            {
                db.TeamAwards.Remove(teamAward);
                db.SaveChanges();
            }
            return RedirectToAction("Index", "Rewards"); // Redirect to Rewards/Index page
        }



        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
