﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using ProjectLens.Models;

namespace ProjectLens.Controllers
{
    public class GrowthTalksController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        private bool IsManager()
        {
            var userId = User.Identity.GetUserId();
            var user = db.Users.Find(userId);
            return user != null && user.IsManager;
        }

        // GET: GrowthTalks
        [Authorize]
        public ActionResult Index()
        {
            ViewBag.IsManager = IsManager();
            var growth = db.GrowthTalks.OrderByDescending(p => p.DateCreated).ToList();
            return View(growth);
            //return View(db.GrowthTalks.ToList());
        }

        // GET: GrowthTalks/Details/5
        [Authorize]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            GrowthTalk growthTalk = db.GrowthTalks.Find(id);
            if (growthTalk == null)
            {
                return HttpNotFound();
            }
            growthTalk.IsRead = true;
            db.SaveChanges();
            return View(growthTalk);
        }

        // GET: GrowthTalks/Create
        [Authorize]
        public ActionResult Create()
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            return View();
        }

        // POST: GrowthTalks/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Title,Description,DateCreated")] GrowthTalk growthTalk)
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            if (ModelState.IsValid)
            {
                db.GrowthTalks.Add(growthTalk);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(growthTalk);
        }

        // GET: GrowthTalks/Edit/5
        [Authorize]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            GrowthTalk growthTalk = db.GrowthTalks.Find(id);
            if (growthTalk == null)
            {
                return HttpNotFound();
            }
            return View(growthTalk);
        }

        // POST: GrowthTalks/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Title,Description,DateCreated")] GrowthTalk growthTalk)
        {
            if (ModelState.IsValid)
            {
                db.Entry(growthTalk).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(growthTalk);
        }

        // POST: GrowthTalks/Delete/5
        [Authorize]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            GrowthTalk growthTalk = db.GrowthTalks.Find(id);
            db.GrowthTalks.Remove(growthTalk);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
