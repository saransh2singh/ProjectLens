﻿using Microsoft.AspNet.Identity;
using ProjectLens.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProjectLens.Controllers
{
        public class RewardsController : Controller
        {
            private readonly ApplicationDbContext db = new ApplicationDbContext();
        private bool IsManager()
        {
            var userId = User.Identity.GetUserId();
            var user = db.Users.Find(userId);
            return user != null && user.IsManager;
        }

        [Authorize]
        public ActionResult Index()
            {
            ViewBag.IsManager = IsManager();
            var viewModel = new RewardPageViewModel
                {
                    Patents = db.Patents.ToList(),
                    TeamAwards = db.TeamAwards.ToList(),
                    IndividualAwards = db.IndividualAwards.ToList()
                };

                return View(viewModel);
            }
    }
}