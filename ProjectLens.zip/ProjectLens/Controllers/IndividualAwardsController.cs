﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using ProjectLens.Models;

namespace ProjectLens.Controllers
{
    public class IndividualAwardsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        private bool IsManager()
        {
            var userId = User.Identity.GetUserId();
            var user = db.Users.Find(userId);
            return user != null && user.IsManager;
        }

        // GET: IndividualAwards
        [Authorize]
        public ActionResult Index()
        {
            ViewBag.IsManager = IsManager();
            return View(db.IndividualAwards.ToList());
        }

        // GET: IndividualAwards/Details/5
        [Authorize]
        public ActionResult Details(int? id)
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            IndividualAward individualAward = db.IndividualAwards.Find(id);
            if (individualAward == null)
            {
                return HttpNotFound();
            }
            return View(individualAward);
        }


        // GET: IndividualAwards/Create
        [Authorize]
        public ActionResult Create()
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            return View();
        }

        // POST: IndividualAwards/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,EmpName,AwardName,AwardedDate")] IndividualAward individualAward)
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            if (ModelState.IsValid)
            {
                db.IndividualAwards.Add(individualAward);
                db.SaveChanges();
                return RedirectToAction("Index", "Rewards");
            }

            return View(individualAward);
        }

        // GET: IndividualAwards/Edit/5
        [Authorize]
        public ActionResult Edit(int? id)
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            IndividualAward individualAward = db.IndividualAwards.Find(id);
            if (individualAward == null)
            {
                return HttpNotFound();
            }
            return View(individualAward);
        }

        // POST: IndividualAwards/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,EmpName,AwardName,AwardedDate")] IndividualAward individualAward)
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            if (ModelState.IsValid)
            {
                db.Entry(individualAward).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", "Rewards");
            }
            return View(individualAward);
        }

        // GET: IndividualAwards/Delete/5
        //public ActionResult Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    IndividualAward individualAward = db.IndividualAwards.Find(id);
        //    if (individualAward == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(individualAward);
        //}

        // POST: IndividualAwards/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(int id)
        //{
        //    IndividualAward individualAward = db.IndividualAwards.Find(id);
        //    db.IndividualAwards.Remove(individualAward);
        //    db.SaveChanges();
        //    return RedirectToAction("Index", "Rewards");
        //}

        [Authorize]
        [HttpPost]
        public ActionResult Delete(int id)
        {
            if (!IsManager())
            {
                return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
            }
            IndividualAward individualAward = db.IndividualAwards.Find(id);
            if (individualAward != null)
            {
                db.IndividualAwards.Remove(individualAward);
                db.SaveChanges();
            }
            return RedirectToAction("Index", "Rewards"); // Redirect to Rewards/Index page
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
