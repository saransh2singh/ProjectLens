﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjectLens.Models
{
    public class TeamAward
    {
        public int Id { get; set; }
        [Required]
        public string TeamName { get; set; }
        [Required]
        public string AwardName { get; set; }
        [Required]
        public DateTime AwardedDate { get; set; }
    }
}