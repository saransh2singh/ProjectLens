﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjectLens.Models
{
    public class Patent
    {
        public int Id { get; set; }
        [Required]
        public string PatentName { get; set; }
        [Required]
        public string InventorName { get; set; }
        [Required]
        public string PatentNumber { get; set; }
        [Required]
        public DateTime GrantedDate { get; set; }
    }
}