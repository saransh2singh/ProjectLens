﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectLens.Models
{
    public class RewardPageViewModel
    {
        public IEnumerable<Patent> Patents { get; set; }
        public IEnumerable<TeamAward> TeamAwards { get; set; }
        public IEnumerable<IndividualAward> IndividualAwards { get; set; }
    }
}