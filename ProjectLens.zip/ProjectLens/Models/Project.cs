﻿using System;
using System.ComponentModel.DataAnnotations; // Add this namespace

namespace ProjectLens.Models
{
    public class Project
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Description is required.")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Start Date is required.")]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "End Date is required.")]
        public DateTime EndDate { get; set; }

        [Required(ErrorMessage = "Status is required.")]
        public string Status { get; set; }

        [Required(ErrorMessage = "Technology Stack is required.")]
        public string TechnologyStack { get; set; }

        [Required(ErrorMessage = "Team Members is required.")]
        public string TeamMembers { get; set; }
    }
}
