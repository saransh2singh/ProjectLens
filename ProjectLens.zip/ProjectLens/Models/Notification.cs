﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ProjectLens.Models
{
    public class Notification
    {
        public int Id { get; set; }

        [Required] 
        public string Title { get; set; }
        [Required]
        public string Description { get; set; }

        [Display(Name = "Date Created")]
        [DisplayFormat(DataFormatString = "{0:dd MMM yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateCreated { get; set; }

        public bool IsRead { get; set; } = false;

        public Notification()
        {
            DateCreated = DateTime.Now;
        }
    }
}
