﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectLens.Helpers
{
    public class StringHelper
    {
        public static string TruncateWords(string text, int wordLimit)
        {
            if (string.IsNullOrWhiteSpace(text)) return text;

            var words = text.Split(' ');
            if (words.Length <= wordLimit)
            {
                return text; // Return the whole description if it's already shorter than the word limit
            }

            return string.Join(" ", words.Take(wordLimit)) + "...";
        }
    }
}