﻿namespace ProjectLens.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedRequired : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.GrowthTalks", "Title", c => c.String(nullable: false));
            AlterColumn("dbo.GrowthTalks", "Description", c => c.String(nullable: false));
            AlterColumn("dbo.IndividualAwards", "EmpName", c => c.String(nullable: false));
            AlterColumn("dbo.IndividualAwards", "AwardName", c => c.String(nullable: false));
            AlterColumn("dbo.Notifications", "Description", c => c.String(nullable: false));
            AlterColumn("dbo.Patents", "PatentName", c => c.String(nullable: false));
            AlterColumn("dbo.Patents", "InventorName", c => c.String(nullable: false));
            AlterColumn("dbo.Patents", "PatentNumber", c => c.String(nullable: false));
            AlterColumn("dbo.TeamAwards", "TeamName", c => c.String(nullable: false));
            AlterColumn("dbo.TeamAwards", "AwardName", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.TeamAwards", "AwardName", c => c.String());
            AlterColumn("dbo.TeamAwards", "TeamName", c => c.String());
            AlterColumn("dbo.Patents", "PatentNumber", c => c.String());
            AlterColumn("dbo.Patents", "InventorName", c => c.String());
            AlterColumn("dbo.Patents", "PatentName", c => c.String());
            AlterColumn("dbo.Notifications", "Description", c => c.String());
            AlterColumn("dbo.IndividualAwards", "AwardName", c => c.String());
            AlterColumn("dbo.IndividualAwards", "EmpName", c => c.String());
            AlterColumn("dbo.GrowthTalks", "Description", c => c.String());
            AlterColumn("dbo.GrowthTalks", "Title", c => c.String());
        }
    }
}
