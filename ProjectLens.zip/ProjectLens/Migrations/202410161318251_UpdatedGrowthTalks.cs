﻿namespace ProjectLens.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdatedGrowthTalks : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.GrowthTalks", "IsRead", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.GrowthTalks", "IsRead");
        }
    }
}
