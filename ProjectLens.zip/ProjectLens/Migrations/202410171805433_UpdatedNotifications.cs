﻿namespace ProjectLens.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdatedNotifications : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Notifications", "Title", c => c.String(nullable: false));
            AlterColumn("dbo.Projects", "Name", c => c.String(nullable: false));
            AlterColumn("dbo.Projects", "Description", c => c.String(nullable: false));
            AlterColumn("dbo.Projects", "Status", c => c.String(nullable: false));
            AlterColumn("dbo.Projects", "TechnologyStack", c => c.String(nullable: false));
            AlterColumn("dbo.Projects", "TeamMembers", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Projects", "TeamMembers", c => c.String());
            AlterColumn("dbo.Projects", "TechnologyStack", c => c.String());
            AlterColumn("dbo.Projects", "Status", c => c.String());
            AlterColumn("dbo.Projects", "Description", c => c.String());
            AlterColumn("dbo.Projects", "Name", c => c.String());
            AlterColumn("dbo.Notifications", "Title", c => c.String());
        }
    }
}
